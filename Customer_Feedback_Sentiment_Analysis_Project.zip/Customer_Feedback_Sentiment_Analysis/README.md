# Customer Feedback Sentiment Analysis System

This project is a data science application that uses both SQL (MySQL) and NoSQL (MongoDB) databases. It performs sentiment analysis on customer feedback data to derive insights into customer satisfaction.

## Project Structure

- **data/** - Contains sample data files.
- **scripts/** - Python scripts for data extraction, processing, and analysis.
- **models/** - Machine learning models for sentiment analysis.
- **notebooks/** - Jupyter notebooks for data exploration and modeling.
- **results/** - Stores result files, such as graphs and reports.

## Requirements

Install the necessary packages using:
```bash
pip install -r requirements.txt
```

## Setup Instructions

1. Set up MySQL and MongoDB databases and import sample data provided in the `data/` folder.
2. Update the database connection details in the scripts.
3. Run the scripts in the `scripts/` folder to extract, process, and analyze data.

## Running the Project

1. **Data Extraction**: `python scripts/extract_data.py`
2. **Sentiment Analysis**: `python scripts/sentiment_analysis.py`
3. **Results Visualization**: Open Jupyter notebooks in the `notebooks/` folder.
