from textblob import TextBlob
import pandas as pd

# Sample data for feedback
feedback_df = pd.DataFrame({
    'CustomerID': [1, 2, 3],
    'FeedbackText': ["Great service", "Not satisfied", "Okay experience"]
})

# Function for sentiment analysis
def analyze_sentiment(text):
    blob = TextBlob(text)
    return blob.sentiment.polarity

# Apply sentiment analysis
feedback_df['Sentiment'] = feedback_df['FeedbackText'].apply(analyze_sentiment)
print(feedback_df[['FeedbackText', 'Sentiment']])
