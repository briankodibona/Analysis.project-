import pymysql
import pymongo
import pandas as pd

# MySQL connection
mysql_conn = pymysql.connect(host='localhost', user='your_user', password='your_pass', db='CustomerDB')
mysql_cursor = mysql_conn.cursor()

# MongoDB connection
mongo_client = pymongo.MongoClient("mongodb://localhost:27017/")
mongo_db = mongo_client["FeedbackDB"]
feedback_collection = mongo_db["Feedback"]

# Extract data from MySQL
mysql_cursor.execute("SELECT * FROM Customers")
customer_data = mysql_cursor.fetchall()

# Extract data from MongoDB
feedback_data = feedback_collection.find()

# Convert to DataFrame for further processing
customer_df = pd.DataFrame(customer_data, columns=['CustomerID', 'Name', 'Email', 'Age'])
feedback_df = pd.DataFrame(feedback_data)
